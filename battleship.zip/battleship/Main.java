package battleship;

import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        GameBoard attacker = new GameBoard("Player 1", scanner);
        promptEnterKey();
        GameBoard defender = new GameBoard("Player 2", scanner);

        GameBoard temporaryBoard;

        while (!attacker.areAllShipsSunk() && !defender.areAllShipsSunk()) {
            printBoardsInfo(attacker);
            Cell targetCell = askAndGetShotTargetCell(scanner);
            String message = attackBoard(attacker, defender, targetCell);
            System.out.println(message);

            temporaryBoard = attacker;
            attacker = defender;
            defender = temporaryBoard;

        }
        System.out.println("You sank the last ship. You won. Congratulations!");

//----------------------------------------------
        // TODO: create class Game
        // playGame()
        // siin lood muutujad attackerBoard, defenderBoard, temporaryBoard ning while loopid seni kaua
        // kuni kummagi laevad on põhja lastud - areAllShipsSunk() (võimalus ka break'iga whilest välja astuda).
        // takeShot()
        // attacker.printOpponentBoard();
        // System.out.println("---------------------");
        // attacker.printOwnBoard();
        // System.out.println("\nPlayer1, it's your turn:");
        // askAndGetValidTargetCell()
        // shotPlacementIsOk
        //    String message = attackBoard(targetCell, attacker, defender);
        //    System.out.println(message);
        // iga tsükkli järel vahetad attackeri ja defenderi lauad (player1, player2).
        // You sank the last ship. You won. Congratulations!

    }

    private static void printBoardsInfo(GameBoard attacker) {
        promptEnterKey();
        attacker.printOpponentBoard();
        System.out.println("---------------------");
        attacker.printOwnBoard();
        System.out.println("\n" + attacker.getPlayerName() + ", it's your turn:");
    }

    private static String attackBoard(GameBoard attacker, GameBoard defender, Cell targetCell) {
        for (Ship ship : defender.getShips()) {
            for (Cell defenderShipCell : ship.getPlacedCells()) {
                if (!defenderShipCell.isHit() && defenderShipCell.equals(targetCell)) {
                    defenderShipCell.setHit(true);
                    defender.getOwnBoard()[targetCell.getRow()][targetCell.getColumn()] = 'X';
                    attacker.getOpponentBoard()[targetCell.getRow()][targetCell.getColumn()] = 'X';
                    if (ship.isShipSunk()) {
                        ship.setSunk(true);
                        return "You sank a ship!";
                    } else {
                        return "You hit a ship!";
                    }
                }
            }
        }

        defender.getOwnBoard()[targetCell.getRow()][targetCell.getColumn()] = 'M';
        attacker.getOpponentBoard()[targetCell.getRow()][targetCell.getColumn()] = 'M';
        return "You missed!";
    }


    public static void promptEnterKey() {
        System.out.println("\nPress Enter and pass the move to another player");
        try {
            System.in.read();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static Cell askAndGetShotTargetCell(Scanner scanner) {
        Coordinates shotCoordinates = getNextShotCoordinates(scanner);
        return new Cell(shotCoordinates.getShotRow(), shotCoordinates.getShotCol());
    }

    private static Coordinates getNextShotCoordinates(Scanner scanner) {
        String input = scanner.next();
        Coordinates coordinates = new Coordinates(input);
        return coordinates;
    }
}

