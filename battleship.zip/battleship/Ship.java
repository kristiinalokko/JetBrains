package battleship;

import java.util.ArrayList;
import java.util.List;

public class Ship {

    private String name;
    private int size;
    private List<Cell> placedCells = new ArrayList<>();
    private List<Cell> adjacentCells = new ArrayList<>();
    private boolean isShipPlaced = false;
    private boolean isSunk = false;

    public Ship(String name, int size) {
        this.name = name;
        this.size = size;
    }


    // Getters, Setters


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public List<Cell> getPlacedCells() {
        return placedCells;
    }

    public void setPlacedCells(List<Cell> placedCells) {
        this.placedCells = placedCells;
    }

    public List<Cell> getAdjacentCells() {
        return adjacentCells;
    }

    public void setAdjacentCells(List<Cell> adjacentCells) {
        this.adjacentCells = adjacentCells;
    }

    public boolean isShipPlaced() {
        return isShipPlaced;
    }

    public void setShipPlaced(boolean shipPlaced) {
        isShipPlaced = shipPlaced;
    }

    public boolean isSunk() {
        return isSunk;
    }

    public void setSunk(boolean sunk) {
        isSunk = sunk;
    }

    public boolean isShipSunk() {
        for (Cell placedCell : placedCells) {
            if (!placedCell.isHit()) {
                return false;
            }
        }
        return true;
    }
}
