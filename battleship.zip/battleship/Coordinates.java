package battleship;

public class Coordinates {

    private int shotRow;
    private int shotCol;

    private int startPosRow;
    private int startPosColumn;
    private int endPosRow;
    private int endPosColumn;
    private boolean isHorizontalPlacement = false;
    private boolean isVerticalPlacement = false;

    // TODO: create letterMap (HashMap)

    // TODO: need to translate valid inputs such
    //  F3 F7 - horizontal
    //  A1 D1 - vertical


    public Coordinates(String start, String end) {
        startPosRow = getMinStartPosRow(start, end);
        startPosColumn = getMinStartPosColumn(start, end);

        endPosRow = getMaxEndPosRow(start, end);
        endPosColumn = getMaxEndPosColumn(start, end);
//
        isHorizontalPlacement = startPosRow == endPosRow;
        isVerticalPlacement = startPosColumn == endPosColumn;
    }

    public Coordinates(String input) {
       shotRow = getNumberFromPosition(input.toUpperCase());
       shotCol = Integer.parseInt(input.substring(1));
    }

    private static int getMaxEndPosColumn(String start, String end) {
        return Math.max(Integer.parseInt(start.substring(1)), Integer.parseInt(end.substring(1)));
    }

    private int getMaxEndPosRow(String start, String end) {
        return Math.max(getNumberFromPosition(start.toUpperCase()), getNumberFromPosition(end.toUpperCase()));
    }

    private static int getMinStartPosColumn(String start, String end) {
        return Math.min(Integer.parseInt(start.substring(1)), Integer.parseInt(end.substring(1)));
    }

    private int getMinStartPosRow(String start, String end) {
        return Math.min(getNumberFromPosition(start.toUpperCase()), getNumberFromPosition(end.toUpperCase()));
    }

    private int getNumberFromPosition(String input) {
        char a = input.charAt(0);
        return Integer.parseInt(String.valueOf(a - 64)) - 1;
    }

    public int getStartPosRow() {
        return startPosRow;
    }

    public void setStartPosRow(int startPosRow) {
        this.startPosRow = startPosRow;
    }

    public int getStartPosColumn() {
        return startPosColumn;
    }

    public void setStartPosColumn(int startPosColumn) {
        this.startPosColumn = startPosColumn;
    }

    public int getEndPosRow() {
        return endPosRow;
    }

    public void setEndPosRow(int endPosRow) {
        this.endPosRow = endPosRow;
    }

    public int getEndPosColumn() {
        return endPosColumn;
    }

    public void setEndPosColumn(int endPosColumn) {
        this.endPosColumn = endPosColumn;
    }

    public boolean isHorizontalPlacement() {
        return isHorizontalPlacement;
    }

    public void setHorizontalPlacement(boolean horizontalPlacement) {
        isHorizontalPlacement = horizontalPlacement;
    }

    public boolean isVerticalPlacement() {
        return isVerticalPlacement;
    }

    public void setVerticalPlacement(boolean verticalPlacement) {
        isVerticalPlacement = verticalPlacement;
    }

    public int getShotRow() {
        return shotRow;
    }

    public void setShotRow(int shotRow) {
        this.shotRow = shotRow;
    }

    public int getShotCol() {
        return shotCol;
    }

    public void setShotCol(int shotCol) {
        this.shotCol = shotCol;
    }
}
