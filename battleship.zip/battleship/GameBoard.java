package battleship;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GameBoard {
    public static final char[] LETTERS = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'};
    public static final int LAST_SHIP_INDEX = 4;
    private String playerName;
    private char[][] opponentBoard;
    private char[][] ownBoard;

    private boolean allShipsArePlaced = false;

    private List<Ship> ships = new ArrayList<>();

    public GameBoard() {
    }

    public GameBoard(String playerName, Scanner scanner) {
        this.playerName = playerName;
        opponentBoard = createBlankBoard();
        ownBoard = createBlankBoard();
        ships = createShips();
        placeAllShips(scanner);
    }

    public boolean areAllShipsSunk(){

        for (Ship ship : ships) {
            if (!ship.isSunk()) {
                return false;
            }
        }

        return true;

    }


    private char[][] createBlankBoard() {
        char[][] boardMatrix = new char[10][11];

        for (int row = 0; row < 10; row++) {
            for (int column = 0; column < 11; column++) {

                if (column == 0) {
                    boardMatrix[row][column] = LETTERS[row];
                } else {
                    boardMatrix[row][column] = '~';
                }

            }
        }

        return boardMatrix;
    }


    private List<Ship> createShips() {
        List<Ship> ships = new ArrayList<>();
        ships.add(new Ship("Aircraft Carrier", 5));
        ships.add(new Ship("Battleship", 4));
        ships.add(new Ship("Submarine", 3));
        ships.add(new Ship("Cruiser", 3));
        ships.add(new Ship("Destroyer", 2));
        return ships;
    }


    private void placeAllShips(Scanner scanner) {
        System.out.println(playerName + ", place your ships on the game field\n");
        printBoard(ownBoard);
        boolean withMessage = true;
        while (!allShipsArePlaced) {
            Ship nextShip = findNextShip();
            Coordinates coordinates = getNextShipCoordinates(scanner, nextShip, withMessage);
            List<Cell> targetCells = createTargetCells(coordinates);
            List<Cell> adjacentCellsCells = createAdjacentCells(coordinates);
            try {
                validateShipLocation(coordinates);
                validateShipLength(nextShip, coordinates);
                validateTargetCellsNotCloseToPlacedShips(targetCells);
            } catch (Exception e) {
                System.out.println(e.getMessage());
                withMessage = false;
                continue;
            }
            withMessage = true;

            nextShip.setPlacedCells(targetCells);
            nextShip.setAdjacentCells(adjacentCellsCells);
            updateOwnBoardWithTargetCells(targetCells);
            printBoard(ownBoard);
            nextShip.setShipPlaced(true);
            allShipsArePlaced = areAllShipsPlaced();
        }
    }

    public void printOwnBoard() {
        printBoard(ownBoard);
    }

    public void printOpponentBoard() {
        printBoard(opponentBoard);
    }


    private void printBoard(char[][] board) {
        StringBuilder sb = new StringBuilder();
        sb.append("  1 2 3 4 5 6 7 8 9 10");

        for (int row = 0; row < 10; row++) {
            sb.append("\n");

            for (int column = 0; column < 11; column++) {
                if (column != 0) {
                    sb.append(" ");
                }
                sb.append(board[row][column]);
            }
        }
        String result = sb.toString();
        System.out.println(result);
    }

    private Ship findNextShip() {
        for (Ship ship : ships) {
            if (!ship.isShipPlaced()) {
                return ship;
            }
        }
        throw new RuntimeException("Ei leidnud ühtegi laeva, mis pole paigutatu (idee järgi sellist olukorda ei saa tekkida)");
    }

    private Coordinates getNextShipCoordinates(Scanner scanner, Ship nextShip, boolean withMessage) {
        if (withMessage) {
            System.out.println("\nEnter the coordinates of the " + nextShip.getName() + " (" + nextShip.getSize() + " cells):\n");
        }
        String start = scanner.next();
        String end = scanner.next();
        Coordinates coordinates = new Coordinates(start, end);
        return coordinates;
    }


    private List<Cell> createTargetCells(Coordinates coordinates) {
        List<Cell> result;

        if (coordinates.isHorizontalPlacement()) {
            result = createHorizontalTargetCells(coordinates);
        } else {
            result = createVerticalTargetCells(coordinates);
        }
        return result;
    }

    private static List<Cell> createHorizontalTargetCells(Coordinates coordinates) {
        List<Cell> result = new ArrayList<>();

        int row = coordinates.getStartPosRow();
        int startCol = coordinates.getStartPosColumn();
        int endCol = coordinates.getEndPosColumn();
        for (int col = startCol; col <= endCol; col++) {
            Cell cell = new Cell();
            cell.setRow(row);
            cell.setColumn(col);
            result.add(cell);
        }
        return result;
    }

    private static List<Cell> createVerticalTargetCells(Coordinates coordinates) {
        List<Cell> result = new ArrayList<>();
        int col = coordinates.getStartPosColumn();

        int startRow = coordinates.getStartPosRow();
        int endRow = coordinates.getEndPosRow();

        for (int row = startRow; row <= endRow; row++) {
            Cell cell = new Cell();
            cell.setRow(row);
            cell.setColumn(col);
            result.add(cell);
        }
        return result;
    }

    private List<Cell> createAdjacentCells(Coordinates coordinates) {
        List<Cell> result;

        if (coordinates.isHorizontalPlacement()) {
            result = createHorizontalAdjacentCells(coordinates);

        } else {
            result = createVerticalAdjacentCells(coordinates);
        }
        return result;
    }

    private static List<Cell> createHorizontalAdjacentCells(Coordinates coordinates) {
        List<Cell> result = new ArrayList<>();
        int row = coordinates.getStartPosRow();
        int startCol = coordinates.getStartPosColumn() - 1;
        int endCol = coordinates.getEndPosColumn() + 1;
        for (int col = startCol; col <= endCol; col++) {

            Cell cellTop = new Cell();
            cellTop.setRow(row - 1);
            cellTop.setColumn(col);
            result.add(cellTop);

            Cell cell = new Cell();
            cell.setRow(row);
            cell.setColumn(col);
            result.add(cell);

            Cell cellBottom = new Cell();
            cellBottom.setRow(row + 1);
            cellBottom.setColumn(col);
            result.add(cellBottom);
        }
        return result;
    }

    private static List<Cell> createVerticalAdjacentCells(Coordinates coordinates) {
        List<Cell> result = new ArrayList<>();
        int col = coordinates.getStartPosColumn();

        int startRow = coordinates.getStartPosRow() - 1;
        int endRow = coordinates.getEndPosRow() + 1;
        for (int row = startRow; row <= endRow; row++) {
            Cell cellLeft = new Cell();
            cellLeft.setRow(row);
            cellLeft.setColumn(col - 1);
            result.add(cellLeft);


            Cell cell = new Cell();
            cell.setRow(row);
            cell.setColumn(col);
            result.add(cell);

            Cell cellRight = new Cell();
            cellRight.setRow(row);
            cellRight.setColumn(col + 1);
            result.add(cellRight);
        }
        return result;
    }

    private void validateShipLocation(Coordinates coordinates) throws Exception {
        if (!coordinates.isHorizontalPlacement() && !coordinates.isVerticalPlacement()) {
            throw new Exception("Error! Wrong ship location! Try again:");
        }
    }
    private void validateShipLength(Ship ship, Coordinates coordinates) throws Exception {
        if (coordinates.isHorizontalPlacement()) {
            validateHorizontalShipLength(ship, coordinates);
        } else {
            validateVerticalShipLength(ship, coordinates);
        }

    }

    private static void validateVerticalShipLength(Ship ship, Coordinates coordinates) throws Exception {
        int rowDifference = (coordinates.getEndPosRow() - coordinates.getStartPosRow()) + 1;
        if (rowDifference > ship.getSize()) {
            throw new Exception("Error! Wrong length of the " + ship.getName() + "! Try again:");
        }
    }

    private static void validateHorizontalShipLength(Ship ship, Coordinates coordinates) throws Exception {
        int columnsDifference = (coordinates.getEndPosColumn() - coordinates.getStartPosColumn()) + 1;
        if (columnsDifference > ship.getSize()) {
            throw new Exception("Error! Wrong length of the " + ship.getName() + "! Try again:");
        }
    }

    private boolean areAllShipsPlaced() {
        Ship ship = ships.get(LAST_SHIP_INDEX);
        return ship.isShipPlaced();
    }

    private void validateTargetCellsNotCloseToPlacedShips(List<Cell> targetCells) throws Exception {
        for (Cell targetCell : targetCells) {
            for (Ship ship : ships) {
                for (Cell adjacentCell : ship.getAdjacentCells()) {
                    if (targetCell.equals(adjacentCell)) {
                        throw new Exception("Error! You placed it too close to another one. Try again:");
                    }
                }
            }
        }
    }




    private void updateOwnBoardWithTargetCells(List<Cell> targetCells) {
        for (Cell targetCell : targetCells) {
            ownBoard[targetCell.getRow()][targetCell.getColumn()] = 'O';
        }
    }


    // TODO: create methods
    // createBlankBoard() - use for both (opponentBoard, ownBoard) - DONE
    // createShips() - DONE

    // placeAllShips() - WIP
    // sout Player 1, place your ships on the game field
    // printBoard(ownBoard); - DONE
    // while (!allShipsPlaced) - DONE
    // findNextShip() - DONE
    // askCoordinates() - DONE
    // createTargetCells(coordinates) - DONE
    // nextShip.setPlacedCells(targetCells); - DONE
    // createAdjacentCells(coordinates) - DONE
    // nextShip.setAdjacent(adjacentCells); - DONE
    // nextShip.setShipPlaced(true); - DONE
    // updateOwnBoardWithTargetCells(targetCells); - DONE
    // printBoard(ownBoard); - DONE


    // Kui happy path osa on valmis, siis tuleks teha ära ka mitte lubatud laeva paigutused

    // Siis tuleks valideerida vea olukorrad - DONE

    // > J7 J10 - DONE
    //Error! Wrong length of the Submarine! Try again:
    // Vastavalt horizontal, vertical paigutusele arvutada coordinates'i
    // järgi paigutatava laeva pikkus tema nõutud suuruse vastu

    // > B9 D8 - DONE
    //Error! Wrong ship location! Try again:
    // Kui laeva paigutuse ei ole vertikaalne, ega horizontaalne

    // > E6 D6 - DONE
    //Error! You placed it too close to another one. Try again:
    // Tuleb vaadata olemasolevate laevade adjecantCells vastu, et kas target cells kattuvad


    // getters, setters


    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public char[][] getOpponentBoard() {
        return opponentBoard;
    }

    public void setOpponentBoard(char[][] opponentBoard) {
        this.opponentBoard = opponentBoard;
    }

    public char[][] getOwnBoard() {
        return ownBoard;
    }

    public void setOwnBoard(char[][] ownBoard) {
        this.ownBoard = ownBoard;
    }

    public boolean isAllShipsArePlaced() {
        return allShipsArePlaced;
    }

    public void setAllShipsArePlaced(boolean allShipsArePlaced) {
        this.allShipsArePlaced = allShipsArePlaced;
    }

    public List<Ship> getShips() {
        return ships;
    }

    public void setShips(List<Ship> ships) {
        this.ships = ships;
    }
}
