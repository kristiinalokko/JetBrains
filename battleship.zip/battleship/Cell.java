package battleship;

import java.util.Objects;

public class Cell {

    private int row;
    private int column;
    private boolean isHit = false;


    public Cell() {
    }

    public Cell(int row, int column) {
        this.row = row;
        this.column = column;
    }


    // getters, setters

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getColumn() {
        return column;
    }

    public void setColumn(int column) {
        this.column = column;
    }

    public boolean isHit() {
        return isHit;
    }

    public void setHit(boolean hit) {
        isHit = hit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cell cell = (Cell) o;
        return row == cell.row && column == cell.column && isHit == cell.isHit;
    }

    @Override
    public int hashCode() {
        return Objects.hash(row, column, isHit);
    }
}
